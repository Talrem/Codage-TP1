# TP-Codage

Mise en oeuvre en language C du codage d'Hadamard

Le principe est de générer une matrice d'Hadamard en fonction du nombre d'utilisateur.
Chaque utilisateur génère un message sur 3 bits.
Des séquences sont utilisées a partir de la matrice pour coder le message.
Le message codé passe ensuite par un canal ( Idéal ou Rayleigh )
Un recepteur reçoit le message et le décode.
