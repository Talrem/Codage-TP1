#include <stdlib.h>
#include <stdio.h>
#include "recepteur.h"

int recepteur(int * mot_code){
	return(1);
}