int canal(int * mot_code);
