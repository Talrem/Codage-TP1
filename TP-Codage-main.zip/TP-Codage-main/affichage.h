void afficher_hadamard(int ** mat, int);
void afficher_tab_int(int tab[], int taille);
void afficher_separateur();