#include <stdlib.h>
#include <stdio.h>
#include "canal.h"

int canal(int * mot_code){
	return(1);
}