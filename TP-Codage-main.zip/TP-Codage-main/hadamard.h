#define MAX_TAB 32

void init_mat(int ** mat, int taille);
int pow1(int n,int p);
int pow2(int n);
int taille_mat_selon_user(int nb_users);
void generer_hadamard(int ** hada, int n);
int selecteur(int n);
int mainHada();